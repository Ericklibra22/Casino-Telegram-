import random

def jugar_tragamonedas():
    simbolos = ["🍒", "🍋", "🍉", "⭐", "💎"]
    resultado = [random.choice(simbolos) for _ in range(3)]
    
    mensaje = f"🎰 {' | '.join(resultado)} 🎰\n"
    if resultado[0] == resultado[1] == resultado[2]:  # Línea ganadora
        premio = 10  # Ajusta el premio
        mensaje += f"🎉 ¡Ganaste {premio} USDT!"
    else:
        premio = 0
        mensaje += "😢 No ganaste, ¡inténtalo de nuevo!"
    
    return mensaje, premio
