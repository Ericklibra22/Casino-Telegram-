import telebot
from config import TOKEN, OWNER_ID
from slot import jugar_tragamonedas
from database import registrar_usuario, obtener_saldo, actualizar_saldo

bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start'])
def start(message):
    chat_id = message.chat.id
    registrar_usuario(chat_id)
    bot.send_message(chat_id, "🎰 ¡Bienvenido al casino en Telegram! Usa /saldo para ver tu saldo o /jugar para probar suerte.")

@bot.message_handler(commands=['saldo'])
def saldo(message):
    chat_id = message.chat.id
    saldo = obtener_saldo(chat_id)
    bot.send_message(chat_id, f"💰 Tu saldo actual es: {saldo} USDT")

@bot.message_handler(commands=['jugar'])
def jugar(message):
    chat_id = message.chat.id
    resultado, premio = jugar_tragamonedas()
    bot.send_message(chat_id, resultado)
    
    if premio > 0:
        actualizar_saldo(chat_id, premio)
        bot.send_message(chat_id, f"🎉 ¡Ganaste {premio} USDT!")

bot.polling()
