import sqlite3

conn = sqlite3.connect("casino.db", check_same_thread=False)
cursor = conn.cursor()

cursor.execute("""CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER UNIQUE,
    saldo REAL DEFAULT 0
)""")
conn.commit()

def registrar_usuario(chat_id):
    cursor.execute("INSERT OR IGNORE INTO usuarios (chat_id) VALUES (?)", (chat_id,))
    conn.commit()

def obtener_saldo(chat_id):
    cursor.execute("SELECT saldo FROM usuarios WHERE chat_id = ?", (chat_id,))
    saldo = cursor.fetchone()
    return saldo[0] if saldo else 0

def actualizar_saldo(chat_id, monto):
    cursor.execute("UPDATE usuarios SET saldo = saldo + ? WHERE chat_id = ?", (monto, chat_id))
    conn.commit()
